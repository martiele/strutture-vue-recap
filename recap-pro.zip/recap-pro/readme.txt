Abbiamo :
- stampa di una lista di giocatori (v-for)
- ricerca filtrata dei giocati (keyUp)
- al click mostriamo le statistiche del giocate (@click)
- possibilità di modifica del punteggio ottenuto dal giocatore (v-model)
- in base al punteggio del giocatore mostriamo una classe o no (v-bind)
- aggiunta di una nuova partita (@click)
- mostrare un titolo per la sezione partite (v-if, v-else)
- rimozione di una partita tramite icona (@click)
- aggiunta nuovo giocatore (@click)

Rivedi tranquillamente ciò che preferisci ovviamente! :)
Dobbiamo pensare come mostrare la grafica al pronti via!
