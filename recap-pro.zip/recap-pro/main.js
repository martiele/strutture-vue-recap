const { createApp } = Vue;

createApp({
    data() {
        return {
            readRimbalzi: true,
            updateRimbalzi: false,
            editStats: {
                punti: false
            },
            players: [
                {
                    nome: "Clarence Erickson",
                    rimbalzi: 15,
                    falli: 11,
                    puntiSegnati: 46,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Jorge McGee",
                    rimbalzi: 5,
                    falli: 15,
                    puntiSegnati: 34,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Bryan Baldwin",
                    rimbalzi: 20,
                    falli: 20,
                    puntiSegnati: 41,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Stephen Kaufman",
                    rimbalzi: 13,
                    falli: 11,
                    puntiSegnati: 39,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Ian Graham",
                    rimbalzi: 18,
                    falli: 19,
                    puntiSegnati: 44,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Jerome Rowe",
                    rimbalzi: 18,
                    falli: 10,
                    puntiSegnati: 32,
                    visible: true,
                    matches: []
                },
                {
                    nome: "William Giles",
                    rimbalzi: 9,
                    falli: 18,
                    puntiSegnati: 30,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Jaime Jenkins",
                    rimbalzi: 11,
                    falli: 10,
                    puntiSegnati: 36,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Arnold Valenzuela",
                    rimbalzi: 14,
                    falli: 16,
                    puntiSegnati: 45,
                    visible: true,
                    matches: []
                },
                {
                    nome: "Timothy Stafford",
                    rimbalzi: 7,
                    falli: 10,
                    puntiSegnati: 32,
                    visible: true,
                    matches: []
                }
            ],
            contactActive: 0,
            searchContactText: '',
            newMatch: '',
            newPlayer: '',
        }
    },
    mounted() {
    },
    methods: {
        setActiveConversation(index) {
            this.contactActive = index;
        },
        searchPlayers() {

            //filtriamo i contatti
            this.players.forEach((element) => {
                if (element.nome.toLowerCase().includes(this.searchContactText.toLowerCase())) {
                    element.visible = true;
                } else {
                    element.visible = false;
                }
            });
        },
        addMatch() {

            if (this.newMatch.trim() == '') {

                alert('Il campo non può essere vuoto!')
            } else {

                this.players[this.contactActive].matches.push(this.newMatch);

                this.newMatch = "";
            }
        },
        deleteMatch(index) {

            console.log('delete', index);

            this.players[this.contactActive].matches.splice(index, 1);

            console.log('....', this.players[this.contactActive].matches);
        },
        getRandom(min, max) {
            const random = Math.floor(Math.random() * (max - min + 1) + min);
            return random;
        },
        addPlayer() {
            if (this.newPlayer.trim() == '') {
                alert('Il campo non può essere vuoto!')
            } else {

                const player = {
                    nome: this.newPlayer,
                    rimbalzi: this.getRandom(5, 20),
                    falli: this.getRandom(10, 20),
                    puntiSegnati: this.getRandom(25, 55),
                    visible: true,
                    matches: []
                };

                this.players.push(player);
                this.newPlayer = "";
            }
        }
    }
}).mount('#app');